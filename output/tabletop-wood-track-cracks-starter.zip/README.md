# Tabletop wooden-track crack dataset starter

This starter set contains four photos of the project's tabletop wooden track. The supplied photos show the track, wood grain, and a normal piece joint; they do not show a clearly verifiable crack. Therefore, all four YOLO label files are intentionally empty and these are negative/background examples only.

Do not treat the circled joint/gap as a crack unless inspection confirms it is damage. Add close-up photos of real cracks, draw a YOLO bounding box around each crack with class `0`, and keep each physical crack/photo session in only one split. Add verified negatives (grain, shadows, joints, clean wood) to teach the model what not to flag.

Folders are initialized for `train`, `val`, and `test`, but only `train` currently contains images. The dataset is not sufficient to train a useful crack detector until verified positive crack examples are added. The detector class is unified as `crack`, so this can later be combined with metal crack images after converting all positive labels to class `0`.

YOLO detection label format per line: `class_id x_center y_center width height`, with coordinates normalized to 0–1. Empty `.txt` means the image has no labeled crack.
